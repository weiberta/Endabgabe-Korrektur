"use strict";
var FireworkCrafting;
(function (FireworkCrafting) {
    class Vector2D {
        constructor(x, y) {
            this.x = x;
            this.y = y;
        }
    }
    FireworkCrafting.Vector2D = Vector2D;
})(FireworkCrafting || (FireworkCrafting = {}));
//# sourceMappingURL=Vector.js.map